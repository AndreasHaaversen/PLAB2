import ciphers

def load_words():
        out = set()
        with open('english_words.txt', 'r') as file:
            for line in file:
                out.add(line.rstrip())
        return out
    
print("" in load_words())